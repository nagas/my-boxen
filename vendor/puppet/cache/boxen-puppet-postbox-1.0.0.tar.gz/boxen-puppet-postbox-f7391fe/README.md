# Postbox Puppet Module for Boxen

## Usage

```puppet
include Postbox
```

## Required Puppet Modules

* boxen

